#ifndef TENSOR_H
#define TENSOR_H


#include "stdint.h"
#include <cstdio>
#include <stdio.h>
#include <stdexcept>
#include <sys/time.h>

#define FLOAT float


#define TENSOR_READ_SUCCSEFULL	0
#define TENSOR_READ_RESIZED		1
#define TENSOR_READ_FAILED 		2

#define chnl_rdn_factor 1
#define inputWidth  16//6//33//6
#define KernelSize  3//4//3//4
#define num_chnl_op 384//3//256//3
#define num_chnl_ip 384//2//256//2
#define NumKernels  384//3//256//3
#define outDim (inputWidth-KernelSize+1)

/******************************/


typedef struct TwoD_struct_input {
    float X_c[inputWidth][inputWidth];
} TwoD_IPT;

typedef struct TwoD_struct_kernel {
    float W_c[KernelSize][KernelSize];
} TwoD_filterT;

typedef struct TwoD_struct_wt_nonDRAM {

    TwoD_filterT ith_filter[num_chnl_ip/chnl_rdn_factor];

} TwoD_nonDRAM_wtT;

typedef struct TwoD_struct_wt {

    TwoD_filterT ith_filter[num_chnl_ip];

} TwoD_wtT;

typedef struct TwoD_struct_out {
    float Z_out[outDim][outDim];

}TwoD_outT;

typedef struct TwoDTile_IPT_tile{
	float tileData[KernelSize][inputWidth];
}TwoDTile_IPT;


typedef struct tensorToFpgaStruct {

	TwoD_IPT X[num_chnl_ip];
	TwoD_outT Z[num_chnl_op];
	TwoD_wtT W[num_chnl_op];
	float B[num_chnl_op];

}tensorToFpgaStructT,
*tensorToFpgaStructP;



/******************************/

class Tensor{
	private:
		int allocated;

	public:
		FLOAT *** data;
		void allocate(uint32_t dim_z, uint32_t dim_y, uint32_t dim_x);
		uint32_t size[3];
		// Constructor and Destructor
		Tensor(uint32_t dim_z, uint32_t dim_y, uint32_t dim_x);
		// Creates an empty un- allocated Tensor
		Tensor();
		// Destructor
		~Tensor();
		// Read and write Tensor to file
		int read(FILE * f);
		void write(FILE * f);
		void resize(uint32_t dim_z, uint32_t dim_y, uint32_t dim_x);
		// Fill Tensor with random values between start and stop
		void randomize(FLOAT start, FLOAT stop);
		// Easy access to the data
		FLOAT ** operator[](uint32_t i){
			return data[i];
		}
};

// Compare two Tensor arrays of length N 
int compareTensors(Tensor * y, Tensor * ref, int N, float limit);

Tensor * padTensor(Tensor * X , uint32_t pad);

struct timeval mtick();
double mtock(struct timeval start);


#endif
